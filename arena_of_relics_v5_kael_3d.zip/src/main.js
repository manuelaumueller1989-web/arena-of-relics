import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { animateLeviathan } from './eye_of_leviathan.js';

// ----- Lightweight 3D/particle layer -----
// The current hero background is the approved concept art.
// This Three.js layer adds real-time atmosphere on top and is the insertion
// point for the future GLB relic and character models.

const canvas = document.getElementById('fx-canvas');
const renderer = new THREE.WebGLRenderer({
  canvas,
  alpha: true,
  antialias: false,
  powerPreference: 'high-performance'
});

renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setClearColor(0x000000, 0);

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(
  50,
  window.innerWidth / window.innerHeight,
  0.1,
  100
);
camera.position.z = 10;

camera.position.z = 10;

// ----- Real GLB relic -----
let leviathan = null;
let leviathanRoot = null;
const gltfLoader = new GLTFLoader();

gltfLoader.load(
  './assets/relics/eye_of_leviathan.glb',
  (gltf) => {
    leviathanRoot = gltf.scene;
    leviathanRoot.name = 'LeviathanRelic';
    leviathanRoot.position.set(0, 0.25, 1.0);
    leviathanRoot.scale.setScalar(window.innerWidth < 760 ? 1.55 : 2.15);

    // Fit the authored model automatically around the center.
    const box = new THREE.Box3().setFromObject(leviathanRoot);
    const center = box.getCenter(new THREE.Vector3());
    leviathanRoot.position.x -= center.x;
    leviathanRoot.position.y -= center.y;
    leviathanRoot.position.y += 0.25;
    leviathanRoot.position.z += 1.0;

    scene.add(leviathanRoot);
    leviathan = animateLeviathan(gltf);

    // Model-local lighting; materials/textures still control the authored look.
    const key = new THREE.DirectionalLight(0xf2c77a, 2.2);
    key.position.set(3, 5, 6);
    scene.add(key);

    const cyan = new THREE.PointLight(0x18dff5, 7, 9, 2);
    cyan.position.set(0, 0.5, 4);
    scene.add(cyan);
  },
  undefined,
  (error) => {
    console.error('Leviathan GLB konnte nicht geladen werden:', error);
  }
);

// Cyan magic motes
const moteCount = window.innerWidth < 760 ? 65 : 160;
const positions = new Float32Array(moteCount * 3);
const speeds = new Float32Array(moteCount);

for (let i = 0; i < moteCount; i++) {
  positions[i * 3] = (Math.random() - 0.5) * 18;
  positions[i * 3 + 1] = (Math.random() - 0.5) * 10;
  positions[i * 3 + 2] = (Math.random() - 0.5) * 6;
  speeds[i] = 0.15 + Math.random() * 0.45;
}

const moteGeometry = new THREE.BufferGeometry();
moteGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));

const moteMaterial = new THREE.PointsMaterial({
  color: 0x2fe8ff,
  size: window.innerWidth < 760 ? 0.035 : 0.045,
  transparent: true,
  opacity: 0.52,
  depthWrite: false,
  blending: THREE.AdditiveBlending
});

const motes = new THREE.Points(moteGeometry, moteMaterial);
scene.add(motes);

// Warm embers near lower arena
const emberCount = window.innerWidth < 760 ? 30 : 90;
const emberPositions = new Float32Array(emberCount * 3);
const emberSpeeds = new Float32Array(emberCount);

for (let i = 0; i < emberCount; i++) {
  emberPositions[i * 3] = (Math.random() - 0.5) * 18;
  emberPositions[i * 3 + 1] = -5 + Math.random() * 3.2;
  emberPositions[i * 3 + 2] = (Math.random() - 0.5) * 5;
  emberSpeeds[i] = 0.1 + Math.random() * 0.3;
}

const emberGeometry = new THREE.BufferGeometry();
emberGeometry.setAttribute('position', new THREE.BufferAttribute(emberPositions, 3));

const emberMaterial = new THREE.PointsMaterial({
  color: 0xf4ad4c,
  size: 0.035,
  transparent: true,
  opacity: 0.55,
  depthWrite: false,
  blending: THREE.AdditiveBlending
});

const embers = new THREE.Points(emberGeometry, emberMaterial);
scene.add(embers);

const clock = new THREE.Clock();

function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), 0.04);

  if (leviathan) leviathan.update(dt);
  if (leviathanRoot) {
    leviathanRoot.rotation.y += dt * 0.10;
  }

  const p = moteGeometry.attributes.position.array;
  for (let i = 0; i < moteCount; i++) {
    p[i * 3 + 1] += speeds[i] * dt;
    p[i * 3] += Math.sin(performance.now() * 0.0005 + i) * 0.0008;

    if (p[i * 3 + 1] > 5) {
      p[i * 3 + 1] = -5;
      p[i * 3] = (Math.random() - 0.5) * 18;
    }
  }
  moteGeometry.attributes.position.needsUpdate = true;

  const e = emberGeometry.attributes.position.array;
  for (let i = 0; i < emberCount; i++) {
    e[i * 3 + 1] += emberSpeeds[i] * dt;
    if (e[i * 3 + 1] > -1.7) {
      e[i * 3 + 1] = -5;
      e[i * 3] = (Math.random() - 0.5) * 18;
    }
  }
  emberGeometry.attributes.position.needsUpdate = true;

  renderer.render(scene, camera);
}

animate();

window.addEventListener('resize', () => {
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
  renderer.setSize(window.innerWidth, window.innerHeight);
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();

  if (leviathanRoot) {
    leviathanRoot.scale.setScalar(window.innerWidth < 760 ? 1.55 : 2.15);
  }
});

// ----- Menu / prototype navigation -----

const modal = document.getElementById('modal');
const modalTitle = document.getElementById('modal-title');
const modalText = document.getElementById('modal-text');
const modalContent = document.getElementById('modal-content');
const modalKicker = document.getElementById('modal-kicker');

const views = {
  arena: {
    kicker: 'DIE ARENA',
    title: 'Arena betreten',
    text: 'Im nächsten Entwicklungsschritt startet hier das Matchmaking. Zwei Spieler setzen Relikte ein, verstecken sie auf zwei von sieben Positionen und treten in der Aufspürphase gegeneinander an.',
    stats: [
      ['7', 'POSITIONEN'],
      ['2', 'VERSTECKTE RELIKTE'],
      ['1×', 'AUFSPÜR-VERSUCH']
    ]
  },
  collection: {
    kicker: 'RELIKTKODEX',
    title: 'Deine Sammlung',
    text: 'Das langfristige Ziel sind 1.000 einzigartige Relikte. Sonderrunden und Events bringen exklusive Artefakte in den globalen Spieler-Pool.',
    stats: [
      ['0', 'ENTDECKT'],
      ['1000', 'GESAMT'],
      ['0%', 'FORTSCHRITT']
    ]
  },
  character: {
    kicker: 'JÄGERAUSWAHL',
    title: 'Wähle deinen Charakter',
    text: 'Hier entstehen die spielbaren Figuren. Zunächst wählen wir einen Charakter aus und stellen anschließend 10 von 50 verfügbaren Insignien und Gegenständen zusammen.',
    stats: [
      ['8', 'GEPLANTE JÄGER'],
      ['50', 'START-RELIKTE'],
      ['10', 'AUSWAHL']
    ]
  },
  settings: {
    kicker: 'SYSTEM',
    title: 'Einstellungen',
    text: 'Grafik, Sound, Sprache, Account und Barrierefreiheit werden hier später konfiguriert.',
    stats: [
      ['AUTO', 'GRAFIK'],
      ['DE', 'SPRACHE'],
      ['WEB', 'PLATTFORM']
    ]
  }
};

function openView(name) {
  if (name === 'home') {
    modal.classList.add('hidden');
    return;
  }

  const view = views[name];
  if (!view) return;

  modalKicker.textContent = view.kicker;
  modalTitle.textContent = view.title;
  modalText.textContent = view.text;

  modalContent.innerHTML = `
    <div class="stat-grid">
      ${view.stats.map(([value, label]) => `
        <div class="stat">
          <strong>${value}</strong>
          <span>${label}</span>
        </div>
      `).join('')}
    </div>
  `;

  modal.classList.remove('hidden');
}

document.querySelectorAll('[data-view]').forEach(button => {
  button.addEventListener('click', () => openView(button.dataset.view));
});

document.getElementById('modal-close').addEventListener('click', () => {
  modal.classList.add('hidden');
});

modal.addEventListener('click', event => {
  if (event.target === modal) modal.classList.add('hidden');
});

// Simple pointer parallax on desktop.
if (matchMedia('(pointer:fine)').matches) {
  const bg = document.querySelector('.scene-bg');
  window.addEventListener('pointermove', event => {
    const x = (event.clientX / window.innerWidth - 0.5) * -0.55;
    const y = (event.clientY / window.innerHeight - 0.5) * -0.35;
    bg.style.backgroundPosition = `${50 + x}% ${50 + y}%`;
  });
}

// Remove loader only after the visual backdrop is available.
// Includes timeout fallback so a network/module issue never traps the user.
const loading = document.getElementById('loading');

function finishLoading() {
  loading.classList.add('done');
}

const preload = new Image();
preload.src = './assets/arena-home-bg.png';
preload.onload = () => setTimeout(finishLoading, 500);
preload.onerror = () => finishLoading();

setTimeout(finishLoading, 3500);



// ----- V5: live Kael GLB -----
const characterHost=document.getElementById('character-figure');
const characterStatus=document.getElementById('character-3d-status');
let charRenderer,charScene,charCamera,charMixer,charModel;
const charClock=new THREE.Clock();
let charPointerX=0;

function ensureCharacterRenderer(){
 if(charRenderer||!characterHost)return;
 charRenderer=new THREE.WebGLRenderer({antialias:true,alpha:true,powerPreference:'high-performance'});
 charRenderer.setPixelRatio(Math.min(devicePixelRatio,1.7));
 charRenderer.outputColorSpace=THREE.SRGBColorSpace;
 charRenderer.toneMapping=THREE.ACESFilmicToneMapping;
 charRenderer.toneMappingExposure=1.15;
 charRenderer.domElement.className='character-canvas';
 characterHost.appendChild(charRenderer.domElement);
 charScene=new THREE.Scene();
 charCamera=new THREE.PerspectiveCamera(28,1,.1,100);
 charCamera.position.set(0,1.7,5.8);
 charScene.add(new THREE.HemisphereLight(0xcfefff,0x1a1209,2.1));
 const key=new THREE.DirectionalLight(0xffd28a,4.2); key.position.set(3,5,4); charScene.add(key);
 const rim=new THREE.DirectionalLight(0x19dff2,3); rim.position.set(-4,3,-3); charScene.add(rim);
 new ResizeObserver(resizeCharacterRenderer).observe(characterHost);
 charRenderer.domElement.addEventListener('pointermove',e=>{const r=charRenderer.domElement.getBoundingClientRect();charPointerX=(e.clientX-r.left)/r.width-.5});
 charRenderer.domElement.addEventListener('pointerleave',()=>charPointerX=0);
 resizeCharacterRenderer(); animateCharacter();
}
function resizeCharacterRenderer(){
 if(!charRenderer)return;
 const w=Math.max(1,characterHost.clientWidth),h=Math.max(1,characterHost.clientHeight);
 charRenderer.setSize(w,h,false);charCamera.aspect=w/h;charCamera.updateProjectionMatrix();
}
async function loadKael3D(){
 ensureCharacterRenderer();
 if(charModel){charModel.visible=true;characterHost.classList.add('has-3d');return}
 try{
  const gltf=await new GLTFLoader().loadAsync('./assets/characters/kael_guardian.glb');
  charModel=gltf.scene;
  const box=new THREE.Box3().setFromObject(charModel),size=box.getSize(new THREE.Vector3()),center=box.getCenter(new THREE.Vector3());
  charModel.position.set(-center.x,-box.min.y,-center.z);
  charModel.scale.setScalar(3.55/Math.max(size.y,.001));
  charScene.add(charModel);
  charMixer=new THREE.AnimationMixer(charModel);
  const idle=gltf.animations.find(a=>a.name.toLowerCase()==='idle')||gltf.animations[0];
  if(idle)charMixer.clipAction(idle).play();
  characterHost.classList.add('has-3d');
 }catch(e){console.error(e);characterStatus.textContent='KAEL KONNTE NICHT GELADEN WERDEN'}
}
function animateCharacter(){
 requestAnimationFrame(animateCharacter);
 if(!charRenderer)return;
 const dt=Math.min(charClock.getDelta(),.04);
 if(charMixer)charMixer.update(dt);
 if(charModel){const target=charPointerX*.35;charModel.rotation.y+=(target-charModel.rotation.y)*Math.min(1,dt*3)}
 charRenderer.render(charScene,charCamera);
}

// ----- V4: Prototype login + character onboarding -----
const authScreen = document.getElementById('auth-screen');
const characterScreen = document.getElementById('character-screen');
const hunterInput = document.getElementById('hunter-name');

const characters = [
  {
    id:'kael', name:'KAEL', title:'DER WÄCHTER', role:'WÄCHTER',
    signature:'EID DES ALTEN TORES',
    lore:'Ein schweigsamer Hüter der alten Arena. Kael trägt die Zeichen einer untergegangenen Dynastie und gibt kein Relikt kampflos auf.'
  },
  {
    id:'nyra', name:'NYRA', title:'DIE SEHERIN', role:'SEHERIN',
    signature:'BLICK ZWISCHEN DEN WELTEN',
    lore:'Nyra liest Spuren, die andere nicht sehen. Ihre cyanfarbenen Runen reagieren auf Relikte, lange bevor deren Geheimnisse sichtbar werden.'
  },
  {
    id:'vex', name:'VEX', title:'DER SCHATTEN', role:'SCHATTEN',
    signature:'SCHRITT OHNE ECHO',
    lore:'Niemand weiß, aus welcher Arena Vex stammt. Er setzt auf Täuschung, Geduld und die Kunst, genau dort zu suchen, wo niemand suchen würde.'
  }
];

let activeCharacter = localStorage.getItem('aor_character') || 'kael';
const picker = document.getElementById('character-picker');

function renderCharacters() {
  picker.innerHTML = characters.map(c => `
    <button class="char-card ${c.id === activeCharacter ? 'active' : ''}" data-char="${c.id}">
      <strong>${c.name}</strong><small>${c.title}</small>
    </button>
  `).join('');

  picker.querySelectorAll('[data-char]').forEach(btn => {
    btn.onclick = () => {
      activeCharacter = btn.dataset.char;
      renderCharacters();
    };
  });

  const c = characters.find(x => x.id === activeCharacter);
  if (activeCharacter === 'kael') loadKael3D();
  else {
    if (charModel) charModel.visible = false;
    characterHost?.classList.remove('has-3d');
    if (characterStatus) characterStatus.textContent = `${c.name}: 3D-MODELL NOCH NICHT IMPORTIERT`;
  }
  document.getElementById('char-name').textContent = c.name;
  document.getElementById('char-title').textContent = c.title;
  document.getElementById('char-role').textContent = c.role;
  document.getElementById('char-signature').textContent = c.signature;
  document.getElementById('char-lore').textContent = c.lore;

  const hue = c.id === 'kael' ? '0deg' : c.id === 'nyra' ? '25deg' : '75deg';
  document.querySelector('.character-placeholder').style.filter =
    `hue-rotate(${hue}) drop-shadow(0 15px 35px #000)`;
}

function enterGame() {
  const name = (hunterInput.value || '').trim() || 'Relic Hunter';
  localStorage.setItem('aor_hunter', name);
  authScreen.classList.add('hidden');

  if (!localStorage.getItem('aor_character')) {
    characterScreen.classList.remove('hidden');
    renderCharacters();
  }
}

document.getElementById('login-button').onclick = enterGame;
document.getElementById('register-button').onclick = enterGame;
hunterInput.addEventListener('keydown', e => {
  if (e.key === 'Enter') enterGame();
});

document.getElementById('choose-character').onclick = () => {
  localStorage.setItem('aor_character', activeCharacter);
  characterScreen.classList.add('hidden');
};

document.getElementById('character-back').onclick = () => {
  characterScreen.classList.add('hidden');
};

document.querySelector('[data-view="character"]')?.addEventListener('click', event => {
  event.preventDefault();
  modal.classList.add('hidden');
  characterScreen.classList.remove('hidden');
  renderCharacters();
});

const savedHunter = localStorage.getItem('aor_hunter');
if (savedHunter) {
  hunterInput.value = savedHunter;
  authScreen.classList.add('hidden');
}
renderCharacters();
