# Arena of Relics — Design V2

GitHub-Pages-Prototyp mit dem abgestimmten visuellen Design.

## Enthalten

- Startseite im dunklen Fantasy-/Relikt-Design
- freigegebenes Konzeptbild als aktuelle Hero-Kulisse
- animierte Three.js-Partikel und Glut
- responsive Smartphone-Oberfläche
- Spielerprofil
- Arena-, Sammlung- und Charakter-Menüs
- modale Prototyp-Seiten
- Ladebildschirm mit Fallback
- vorbereitet für spätere `.glb`-Modelle

## Auf GitHub aktualisieren

Wenn bereits ein `arena-of-relics` Repository existiert:

1. ZIP entpacken.
2. Die Dateien und Ordner in das Repository kopieren/hochladen.
3. Bestehende `index.html`, `style.css` und `src/main.js` ersetzen.
4. Den Ordner `assets/` mit hochladen.
5. Commit durchführen.
6. GitHub Pages übernimmt die Änderung automatisch.

## Codespaces testen

Im Terminal im Repository-Root:

```bash
python3 -m http.server 8000 --bind 0.0.0.0
```

Danach unter **Ports** den Port `8000` im Browser öffnen.

## Aktuelle Struktur

```text
arena-of-relics/
├─ index.html
├─ style.css
├─ README.md
├─ assets/
│  └─ arena-home-bg.png
└─ src/
   └─ main.js
```

## Nächster technischer Schritt

Das zentrale Auge des Leviathan wird später vom Hintergrund getrennt und durch ein echtes animiertes 3D-Relikt ersetzt. Die Oberfläche muss dafür nicht neu gebaut werden.


## V3 — echtes GLB-Relikt

Diese Version lädt:

`assets/relics/eye_of_leviathan.glb`

über `GLTFLoader`. Die vorhandenen GLB-Animationen werden über
`src/eye_of_leviathan.js` und `THREE.AnimationMixer` abgespielt.

Beim Testen unbedingt über HTTP/Codespaces/GitHub Pages öffnen, nicht als lokale `file://`-Datei.


## V4 — Login und Charakterauswahl

Neu:
- Login-/Registrierungs-Prototyp
- Jägername wird lokal im Browser gespeichert
- Charakterauswahl mit Kael, Nyra und Vex
- Charakterwahl wird lokal gespeichert
- Hauptmenü öffnet die Charakterauswahl erneut

Wichtig: Dies ist noch **keine sichere Authentifizierung**. `localStorage` dient nur dem UI-/Gameplay-Prototyp. Echte Accounts und Inventare kommen später über ein Backend.


## V5 — Kael 3D
Kael wird als echtes `assets/characters/kael_guardian.glb` geladen. Seine eingebettete Idle-Animation läuft in der Charakterauswahl. Nyra/Vex bleiben bis zum Import ihrer GLBs Platzhalter.
