# Arena of Relics — GitHub Pages 3D Starter

Ein direkt auf GitHub Pages veröffentlichbarer 3D-Prototyp.

## Start lokal
Kein Build-System nötig. Für lokale Entwicklung einen kleinen HTTP-Server verwenden, z.B.:

```bash
python3 -m http.server 8000
```

Dann `http://localhost:8000` öffnen.

## GitHub Pages
1. Repository auf GitHub anlegen.
2. Dateien in den Repository-Root hochladen.
3. Settings → Pages → Deploy from a branch.
4. Branch `main`, Ordner `/ (root)` auswählen.
5. Speichern.

## Technik
- Three.js als ES-Modul über jsDelivr
- WebGL
- OrbitControls
- `.glb`/glTF kann später über `GLTFLoader` eingebunden werden
- Kein Backend im aktuellen Prototyp

## Nächster Schritt
Deine echten `.glb`-Dateien in `assets/` legen. Danach können Charakter, Relikte, Animationen und Arena-Objekte in die Szene integriert werden.
