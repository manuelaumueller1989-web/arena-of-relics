import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.js';
import { OrbitControls } from 'https://cdn.jsdelivr.net/npm/three@0.180.0/examples/jsm/controls/OrbitControls.js';

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x050609);
scene.fog = new THREE.FogExp2(0x08090c, 0.035);

const camera = new THREE.PerspectiveCamera(48, innerWidth / innerHeight, .1, 200);
camera.position.set(10, 7, 15);

const renderer = new THREE.WebGLRenderer({ antialias:true, powerPreference:'high-performance' });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.15;
document.getElementById('game').prepend(renderer.domElement);

const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 2.3, 0);
controls.enablePan = false;
controls.minDistance = 8;
controls.maxDistance = 25;
controls.minPolarAngle = .8;
controls.maxPolarAngle = 1.55;
controls.autoRotate = true;
controls.autoRotateSpeed = .35;

scene.add(new THREE.HemisphereLight(0x8c91ad, 0x08090b, 1.1));

const moon = new THREE.DirectionalLight(0xd8d7e4, 2.3);
moon.position.set(-8, 15, 7);
moon.castShadow = true;
moon.shadow.mapSize.set(2048,2048);
scene.add(moon);

const goldLight = new THREE.PointLight(0xd6a94f, 75, 20, 2);
goldLight.position.set(0, 5, 2);
scene.add(goldLight);

// Ground
const ground = new THREE.Mesh(
  new THREE.CylinderGeometry(13, 14, .5, 96),
  new THREE.MeshStandardMaterial({ color:0x111217, roughness:.9, metalness:.15 })
);
ground.position.y = -.3;
ground.receiveShadow = true;
scene.add(ground);

const inner = new THREE.Mesh(
  new THREE.CylinderGeometry(8.8, 9.2, .12, 96),
  new THREE.MeshStandardMaterial({ color:0x18191e, roughness:.82, metalness:.25 })
);
inner.position.y = -.02;
scene.add(inner);

// Arena ring
function ring(radius, tube, color, y=0.12) {
  const m = new THREE.Mesh(new THREE.TorusGeometry(radius,tube,12,96),
    new THREE.MeshStandardMaterial({color, metalness:.75, roughness:.28, emissive:color, emissiveIntensity:.12}));
  m.rotation.x = Math.PI/2; m.position.y=y; m.castShadow=true; scene.add(m); return m;
}
ring(8.9,.08,0x5d5545);
ring(6.7,.045,0x8b6b36,.1);

// Columns and arches
const stoneMat = new THREE.MeshStandardMaterial({color:0x292a2f, roughness:.78, metalness:.08});
const goldMat = new THREE.MeshStandardMaterial({color:0xb28a45, roughness:.3, metalness:.85});

for(let i=0;i<12;i++){
  const a=i*Math.PI*2/12, r=10.2;
  const group=new THREE.Group();
  const col=new THREE.Mesh(new THREE.CylinderGeometry(.55,.7,7,12),stoneMat);
  col.position.y=3.5; col.castShadow=true; group.add(col);
  const cap=new THREE.Mesh(new THREE.CylinderGeometry(.72,.72,.18,12),goldMat);
  cap.position.y=7.05; group.add(cap);
  const flame=new THREE.Mesh(new THREE.SphereGeometry(.14,12,8),new THREE.MeshBasicMaterial({color:0xffd77a}));
  flame.position.y=7.3; group.add(flame);
  group.position.set(Math.cos(a)*r,0,Math.sin(a)*r);
  group.rotation.y=-a;
  scene.add(group);
  const light=new THREE.PointLight(0xffa52f,2.5,6,2); light.position.copy(group.position); light.position.y=6.7; scene.add(light);
}

// Central relic pedestal
const pedestal = new THREE.Group();
const base=new THREE.Mesh(new THREE.CylinderGeometry(2.2,2.5,.7,48),stoneMat); base.castShadow=true; pedestal.add(base);
const top=new THREE.Mesh(new THREE.CylinderGeometry(1.8,2.0,.25,48),goldMat); top.position.y=.48; pedestal.add(top);
const relic=new THREE.Mesh(new THREE.IcosahedronGeometry(.85,2),
  new THREE.MeshStandardMaterial({color:0xd6b36a,emissive:0x6a4b17,emissiveIntensity:.65,metalness:.8,roughness:.18}));
relic.position.y=1.7; relic.castShadow=true; pedestal.add(relic);
const relicGlow=new THREE.PointLight(0xe5b95f,18,7,2); relicGlow.position.y=1.7; pedestal.add(relicGlow);
scene.add(pedestal);

// Seven positions around arena
const positions=[];
for(let i=0;i<7;i++){
  const a=-Math.PI/2+i*(Math.PI*2/7), r=5.4;
  const marker=new THREE.Mesh(
    new THREE.CylinderGeometry(.55,.55,.08,32),
    new THREE.MeshStandardMaterial({color:0x2b2924,metalness:.6,roughness:.4})
  );
  marker.position.set(Math.cos(a)*r,.06,Math.sin(a)*r);
  marker.userData.index=i+1;
  scene.add(marker); positions.push(marker);
}

// Floating dust / sparks
const dustGeo=new THREE.BufferGeometry();
const count=500, arr=new Float32Array(count*3);
for(let i=0;i<count;i++){
  const a=Math.random()*Math.PI*2, r=3+Math.random()*11;
  arr[i*3]=Math.cos(a)*r; arr[i*3+1]=Math.random()*7; arr[i*3+2]=Math.sin(a)*r;
}
dustGeo.setAttribute('position',new THREE.BufferAttribute(arr,3));
scene.add(new THREE.Points(dustGeo,new THREE.PointsMaterial({color:0xd1b16b,size:.035,transparent:true,opacity:.55})));

// Star field
const starsGeo=new THREE.BufferGeometry();
const stars=new Float32Array(900);
for(let i=0;i<900;i++){ stars[i*3]=(Math.random()-.5)*120; stars[i*3+1]=15+Math.random()*50; stars[i*3+2]=(Math.random()-.5)*120; }
starsGeo.setAttribute('position',new THREE.BufferAttribute(stars,3));
scene.add(new THREE.Points(starsGeo,new THREE.PointsMaterial({color:0x777b88,size:.045,transparent:true,opacity:.5})));

// UI
const panel=document.getElementById('panel');
const content=document.getElementById('panel-content');
document.querySelectorAll('[data-action]').forEach(btn=>btn.addEventListener('click',()=>openPanel(btn.dataset.action)));
document.getElementById('close').onclick=()=>panel.classList.add('hidden');

function openPanel(action){
  const data={
    play:['ARENA BETRETEN','Der nächste Schritt ist das Matchmaking. Im Prototyp ist die Arena bereits vorbereitet: sieben Positionen, zwei versteckte Relikte und eine einzelne Tipp-Phase.',''],
    collection:['DEINE SAMMLUNG','Deine langfristige Aufgabe: 1.000 einzigartige Relikte sammeln. Events und Sonderrunden bringen zeitlich begrenzte Relikte in die Welt.',''],
    character:['CHARAKTER','Wähle später deinen Helden und passe ihn mit Insignien, Relikten und kosmetischen Gegenständen an.','']
  }[action];
  content.innerHTML=`<h2>${data[0]}</h2><p>${data[1]}</p>
    <div class="cards"><div class="card"><b>7</b><small>ARENA-POSITIONEN</small></div>
    <div class="card"><b>2</b><small>RELIKTE PRO RUNDE</small></div>
    <div class="card"><b>1000</b><small>SAMMELZIEL</small></div></div>`;
  panel.classList.remove('hidden');
}

// Simple GLB drop-in helper. Put a file at assets/character.glb later and uncomment loader code.
const clock=new THREE.Clock();
function animate(){
  requestAnimationFrame(animate);
  const t=clock.getElapsedTime();
  relic.rotation.y=t*.8; relic.position.y=1.7+Math.sin(t*1.7)*.16;
  goldLight.intensity=65+Math.sin(t*2.4)*12;
  pedestal.rotation.y=Math.sin(t*.22)*.08;
  controls.update();
  renderer.render(scene,camera);
}
animate();

setTimeout(()=>document.getElementById('loading').classList.add('done'),700);

addEventListener('resize',()=>{
  camera.aspect=innerWidth/innerHeight; camera.updateProjectionMatrix();
  renderer.setSize(innerWidth,innerHeight);
});
