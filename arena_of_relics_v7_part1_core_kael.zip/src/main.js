import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

const $ = (q, root=document) => root.querySelector(q);
const $$ = (q, root=document) => [...root.querySelectorAll(q)];
const loader = new GLTFLoader();

function showScreen(id){
  $$('.screen').forEach(s=>s.classList.toggle('active',s.id===id));
  if(id==='characters') activateCharacter(activeCharacter);
}

/* ---------- Landing relic ---------- */
const relicHost = $('#relic-stage');
let relicRenderer, relicScene, relicCamera, relicMixer, relicModel, relicClock = new THREE.Clock();

function initRelic(){
  relicRenderer = new THREE.WebGLRenderer({antialias:true,alpha:true,powerPreference:'high-performance'});
  relicRenderer.setPixelRatio(Math.min(devicePixelRatio,1.5));
  relicRenderer.outputColorSpace = THREE.SRGBColorSpace;
  relicRenderer.toneMapping = THREE.ACESFilmicToneMapping;
  relicRenderer.toneMappingExposure = 1.15;
  relicHost.appendChild(relicRenderer.domElement);

  relicScene = new THREE.Scene();
  relicCamera = new THREE.PerspectiveCamera(32,1,.1,50);
  relicCamera.position.set(0,.1,5.1);
  relicScene.add(new THREE.HemisphereLight(0xbfe9ff,0x160d05,2.4));
  const key = new THREE.DirectionalLight(0xffc66d,4.2); key.position.set(3,4,5); relicScene.add(key);
  const cyan = new THREE.PointLight(0x23e6ff,8,10,2); cyan.position.set(0,0,3); relicScene.add(cyan);

  new ResizeObserver(resizeRelic).observe(relicHost);
  resizeRelic();

  loader.load('./assets/relics/eye_of_leviathan.glb', gltf=>{
    relicModel=gltf.scene;
    const box=new THREE.Box3().setFromObject(relicModel), size=box.getSize(new THREE.Vector3()), center=box.getCenter(new THREE.Vector3());
    relicModel.position.sub(center);
    relicModel.scale.setScalar(2.8/Math.max(size.x,size.y,size.z,.001));
    relicScene.add(relicModel);
    relicMixer=new THREE.AnimationMixer(relicModel);
    gltf.animations.forEach(a=>relicMixer.clipAction(a).play());
    $('.relic-loading')?.remove();
  },undefined,()=>{$('.relic-loading').textContent='AUGE KONNTE NICHT GELADEN WERDEN';});

  requestAnimationFrame(renderRelic);
}
function resizeRelic(){
  const w=Math.max(relicHost.clientWidth,1), h=Math.max(relicHost.clientHeight,1);
  relicRenderer.setSize(w,h,false); relicCamera.aspect=w/h; relicCamera.updateProjectionMatrix();
}
function renderRelic(){
  requestAnimationFrame(renderRelic);
  const dt=Math.min(relicClock.getDelta(),.04);
  if(relicMixer) relicMixer.update(dt);
  if(relicModel) relicModel.rotation.y += dt*.08;
  relicRenderer.render(relicScene,relicCamera);
}
initRelic();

/* ---------- Auth mock flow ---------- */
const panelIds=['login-panel','register-panel','hunter-panel','success-panel'];
function showPanel(id){panelIds.forEach(p=>$('#'+p).classList.toggle('hidden',p!==id));}

$$('[data-open]').forEach(b=>b.onclick=()=>{
  showScreen('auth'); showPanel(b.dataset.open==='register'?'register-panel':'login-panel');
});
$$('[data-action="back-home"]').forEach(b=>b.onclick=()=>showScreen('landing'));
$$('[data-switch]').forEach(b=>b.onclick=()=>showPanel(b.dataset.switch+'-panel'));

$$('[data-toggle-password]').forEach(b=>b.onclick=()=>{
  const input=$('#'+b.dataset.togglePassword);
  input.type=input.type==='password'?'text':'password';
});

$('#demo-login').onclick=()=>{
  const name=$('#login-user').value.trim() || 'Reliktjäger';
  localStorage.setItem('aor_demo_hunter',name);
  showScreen('characters');
};

$('#demo-register').onclick=()=>{
  showPanel('hunter-panel');
  setTimeout(()=>$('#hunter-name').focus(),100);
};

$('#continue-name').onclick=()=>{
  const value=$('#hunter-name').value.trim();
  if(value.length<3){
    $('#name-status').textContent='Bitte mindestens 3 Zeichen eingeben.';
    $('#name-status').style.color='#d77b65';
    return;
  }
  localStorage.setItem('aor_demo_hunter',value);
  showPanel('success-panel');
};

$('#to-characters').onclick=()=>showScreen('characters');

/* ---------- Characters ---------- */
const characters=[
 {id:'kael',name:'KAEL',title:'DER WÄCHTER',role:'WÄCHTER',signature:'EID DES ALTEN TORES',file:'kael-pbr-idle.glb',lore:'Ein schweigsamer Hüter der alten Arena. Kael trägt die Zeichen einer untergegangenen Dynastie und gibt kein Relikt kampflos auf.'},
 {id:'nyra',name:'NYRA',title:'DIE SEHERIN',role:'SEHERIN',signature:'BLICK ZWISCHEN DEN WELTEN',file:'nyra-pbr-idle.glb',lore:'Nyra liest Spuren, die andere nicht sehen. Ihre cyanfarbenen Runen reagieren auf Relikte, lange bevor deren Geheimnisse sichtbar werden.'},
 {id:'vex',name:'VEX',title:'DER SCHATTEN',role:'SCHATTEN',signature:'SCHRITT OHNE ECHO',file:'vex_shadow.glb',lore:'Niemand weiß, aus welcher Arena Vex stammt. Er setzt auf Täuschung, Geduld und präzise Entscheidungen.'},
 {id:'brakk',name:'BRAKK',title:'DER RELIKTSCHMIED',role:'SCHMIED',signature:'GLUT DER ALTEN SCHMIEDE',file:'brakk_relic_smith.glb',lore:'Brakk kennt den Wert eines Relikts, bevor andere seine Runen entziffern. Seine Werkzeuge tragen Spuren längst vergangener Zivilisationen.'},
 {id:'elya',name:'ELYA',title:'DIE ARKANISTIN',role:'ARKANISTIN',signature:'ARKANE RESONANZ',file:'elya_arcanist.glb',lore:'Elya untersucht die Kräfte hinter den Relikten. Für sie ist die Arena zugleich Schlachtfeld und lebendes Archiv.'},
 {id:'ruun',name:'RUUN',title:'DER SPURENSUCHER',role:'JÄGER',signature:'KOMPASS DER VERLORENEN WEGE',file:'ruun_tracker.glb',lore:'Ruun folgt Spuren, die längst verschwunden scheinen. Kein verlorenes Relikt bleibt für immer verborgen.'},
 {id:'morvek',name:'MORVEK',title:'DER VERFLUCHTE',role:'VERFLUCHTER',signature:'BRUCH DER KRONE',file:'morvek_cursed.glb',lore:'Einst Champion, heute Träger eines Fluchs. Morvek kennt den Preis großer Macht besser als jeder andere Jäger.'},
 {id:'aveline',name:'AVELINE',title:'DIE RELIKTKÖNIGIN',role:'KÖNIGIN',signature:'DIE SIEBEN SIEGEL',file:'aveline_relic_queen.glb',lore:'Aveline herrscht nicht durch Lautstärke, sondern durch Besitz, Wissen und absolute Kontrolle über ihre Sammlung.'}
];
let activeCharacter='kael';
const charHost=$('#character-stage');
const charRenderer=new THREE.WebGLRenderer({antialias:true,alpha:true,powerPreference:'high-performance'});
charRenderer.setPixelRatio(Math.min(devicePixelRatio,1.5));
charRenderer.outputColorSpace=THREE.SRGBColorSpace;
charRenderer.toneMapping=THREE.ACESFilmicToneMapping;
charRenderer.toneMappingExposure=1.13;
charHost.appendChild(charRenderer.domElement);
const charScene=new THREE.Scene();
const charCamera=new THREE.PerspectiveCamera(24,1,.1,100);
charScene.add(new THREE.HemisphereLight(0xcbeeff,0x1c1006,2.2));
const cKey=new THREE.DirectionalLight(0xffd08a,4.1);cKey.position.set(4,6,5);charScene.add(cKey);
const cRim=new THREE.DirectionalLight(0x25e1ff,3.1);cRim.position.set(-4,3,-4);charScene.add(cRim);
const charClock=new THREE.Clock();
const cache=new Map();
let charRoot=null,charMixer=null,loadToken=0,pointerX=0;

new ResizeObserver(resizeChar).observe(charHost);
function resizeChar(){
 const w=Math.max(charHost.clientWidth,1),h=Math.max(charHost.clientHeight,1);
 charRenderer.setSize(w,h,false);charCamera.aspect=w/h;charCamera.updateProjectionMatrix();
}
resizeChar();

charRenderer.domElement.addEventListener('pointermove',e=>{
 const r=charRenderer.domElement.getBoundingClientRect();
 pointerX=((e.clientX-r.left)/r.width-.5);
});
charRenderer.domElement.addEventListener('pointerleave',()=>pointerX=0);

function buildPicker(){
 $('#character-picker').innerHTML=characters.map(c=>`<button class="char-card ${c.id===activeCharacter?'active':''}" data-char="${c.id}"><strong>${c.name}</strong><small>${c.title}</small></button>`).join('');
 $$('[data-char]').forEach(b=>b.onclick=()=>activateCharacter(b.dataset.char));
}
buildPicker();

async function getCharacter(c){
 if(cache.has(c.id)) return cache.get(c.id);
 const gltf=await loader.loadAsync('./assets/characters/'+c.file);
 cache.set(c.id,gltf);return gltf;
}

async function activateCharacter(id){
 activeCharacter=id;
 const c=characters.find(x=>x.id===id);
 $('#char-name').textContent=c.name;$('#char-title').textContent=c.title;
 $('#char-role').textContent=c.role;$('#char-signature').textContent=c.signature;$('#char-lore').textContent=c.lore;
 buildPicker();
 $('.char-loader').classList.remove('hidden');
 $('.char-loader').textContent='JÄGER WIRD GELADEN …';
 const token=++loadToken;
 try{
   const gltf=await getCharacter(c);
   if(token!==loadToken)return;
   if(charRoot) charScene.remove(charRoot);
   if(charMixer) charMixer.stopAllAction();
   charRoot=gltf.scene;
   charScene.add(charRoot);

   // Robust full-body framing: normalize feet to y=0, then frame using vertical FOV.
   const box=new THREE.Box3().setFromObject(charRoot);
   const size=box.getSize(new THREE.Vector3());
   const center=box.getCenter(new THREE.Vector3());
   charRoot.position.set(-center.x,-box.min.y,-center.z);

   // Keep authored scale and move camera, rather than cropping by arbitrary model scale.
   const height=Math.max(size.y,.001);
   const width=Math.max(size.x,.001);
   const fov=THREE.MathUtils.degToRad(charCamera.fov);
   const distForHeight=(height*.58)/Math.tan(fov/2);
   const hFov=2*Math.atan(Math.tan(fov/2)*charCamera.aspect);
   const distForWidth=(width*.60)/Math.tan(hFov/2);
   const distance=Math.max(distForHeight,distForWidth)*1.30;

   charCamera.position.set(0,height*.53,distance);
   charCamera.lookAt(0,height*.50,0);
   charCamera.near=Math.max(.01,distance-height*2);
   charCamera.far=distance+height*5;
   charCamera.updateProjectionMatrix();

   charMixer=new THREE.AnimationMixer(charRoot);
   const idle=gltf.animations.find(a=>a.name.toLowerCase()==='idle')||gltf.animations[0];
   if(idle) charMixer.clipAction(idle).reset().fadeIn(.18).play();
   $('.char-loader').classList.add('hidden');
 }catch(err){
   console.error(err);
   $('.char-loader').textContent='MODELL KONNTE NICHT GELADEN WERDEN';
 }
}

function renderChar(){
 requestAnimationFrame(renderChar);
 const dt=Math.min(charClock.getDelta(),.04);
 if(charMixer)charMixer.update(dt);
 if(charRoot){
   const target=pointerX*.28;
   charRoot.rotation.y+=(target-charRoot.rotation.y)*Math.min(1,dt*3.2);
 }
 charRenderer.render(charScene,charCamera);
}
renderChar();

$('#characters-back').onclick=()=>showScreen('landing');
$('#info-btn').onclick=()=>$('#char-info').classList.add('open');
$('#info-close').onclick=()=>$('#char-info').classList.remove('open');
$('#choose-character').onclick=()=>{
 localStorage.setItem('aor_demo_character',activeCharacter);
 const toast=$('#chosen-toast');toast.classList.add('show');setTimeout(()=>toast.classList.remove('show'),1300);
};

/* Restore harmless prototype choices only */
const saved=localStorage.getItem('aor_demo_character');
if(saved && characters.some(c=>c.id===saved)) activeCharacter=saved;
buildPicker();
