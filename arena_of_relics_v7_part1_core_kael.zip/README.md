# Arena of Relics — V6 Auth/UI Prototype

Diese Version ist bewusst ein **Design- und Navigationsprototyp ohne echtes Backend**.

## Enthalten

- Cinematic Landingpage
- echtes animiertes `eye_of_leviathan.glb`
- Login-Ansicht
- Registrierungs-Ansicht
- Jägername-Schritt
- Erfolgs-/Welcome-Screen
- acht echte Charakter-GLBs:
  - Kael
  - Nyra
  - Vex
  - Brakk
  - Elya
  - Ruun
  - Morvek
  - Aveline
- Character Viewer lädt nur den aktuell gewählten Charakter
- automatische Ganzkörper-Kamera, damit Kopf/Füße nicht abgeschnitten werden
- Mobile-UI mit horizontaler Charakterauswahl und separatem Infofenster

## Wichtig

Login, Registrierung, Social Login, Passwort-Reset und Account-Sicherheit sind in V6 **noch nicht serverseitig implementiert**.
Die Buttons simulieren nur den späteren User Flow. Es werden keine echten Passwörter gespeichert.

## Start in Codespaces

```bash
python3 -m http.server 8000 --bind 0.0.0.0
```

Dann Port 8000 öffnen.

## Später

Für echte Accounts ersetzen wir nur die Demo-Handler durch Auth-/Backend-Aufrufe. Das UI und der Flow können weitgehend bestehen bleiben.
