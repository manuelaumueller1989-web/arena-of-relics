import { AnimationMixer } from 'three';

// After GLTFLoader.loadAsync():
// scene.add(gltf.scene);
// const relic = animateLeviathan(gltf);
// In the render loop: relic.update(deltaSeconds);
// Docs: https://threejs.org/docs/pages/AnimationMixer.html
// https://threejs.org/docs/pages/MeshStandardMaterial.html
export function animateLeviathan(gltf) {
  const mixer = new AnimationMixer(gltf.scene);
  const actions = Object.fromEntries(gltf.animations.map(clip => [clip.name, mixer.clipAction(clip)]));
  const materials = new Set();
  gltf.scene.traverse(object => {
    if (!object.isMesh) return;
    const list = Array.isArray(object.material) ? object.material : [object.material];
    list.forEach(material => {
      if (material.name === 'cyan_emissive') materials.add(material);
    });
  });
  Object.values(actions).forEach(action => action.play());
  return {
    mixer, actions,
    update(deltaSeconds) {
      mixer.update(deltaSeconds);
      const pulse = actions.EyePulse;
      const intensity = pulse && pulse.enabled
        ? 1 + 0.16 * pulse.getEffectiveWeight() * Math.sin(2 * Math.PI * pulse.time / 4)
        : 1;
      materials.forEach(material => { material.emissiveIntensity = intensity; });
    },
    dispose() {
      mixer.stopAllAction();
      mixer.uncacheRoot(gltf.scene);
      materials.forEach(material => { material.emissiveIntensity = 1; });
    }
  };
}
