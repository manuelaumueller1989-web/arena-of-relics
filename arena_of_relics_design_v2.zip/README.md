# Arena of Relics — Design V2

GitHub-Pages-Prototyp mit dem abgestimmten visuellen Design.

## Enthalten

- Startseite im dunklen Fantasy-/Relikt-Design
- freigegebenes Konzeptbild als aktuelle Hero-Kulisse
- animierte Three.js-Partikel und Glut
- responsive Smartphone-Oberfläche
- Spielerprofil
- Arena-, Sammlung- und Charakter-Menüs
- modale Prototyp-Seiten
- Ladebildschirm mit Fallback
- vorbereitet für spätere `.glb`-Modelle

## Auf GitHub aktualisieren

Wenn bereits ein `arena-of-relics` Repository existiert:

1. ZIP entpacken.
2. Die Dateien und Ordner in das Repository kopieren/hochladen.
3. Bestehende `index.html`, `style.css` und `src/main.js` ersetzen.
4. Den Ordner `assets/` mit hochladen.
5. Commit durchführen.
6. GitHub Pages übernimmt die Änderung automatisch.

## Codespaces testen

Im Terminal im Repository-Root:

```bash
python3 -m http.server 8000 --bind 0.0.0.0
```

Danach unter **Ports** den Port `8000` im Browser öffnen.

## Aktuelle Struktur

```text
arena-of-relics/
├─ index.html
├─ style.css
├─ README.md
├─ assets/
│  └─ arena-home-bg.png
└─ src/
   └─ main.js
```

## Nächster technischer Schritt

Das zentrale Auge des Leviathan wird später vom Hintergrund getrennt und durch ein echtes animiertes 3D-Relikt ersetzt. Die Oberfläche muss dafür nicht neu gebaut werden.
