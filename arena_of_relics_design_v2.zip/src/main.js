import * as THREE from 'three';

// ----- Lightweight 3D/particle layer -----
// The current hero background is the approved concept art.
// This Three.js layer adds real-time atmosphere on top and is the insertion
// point for the future GLB relic and character models.

const canvas = document.getElementById('fx-canvas');
const renderer = new THREE.WebGLRenderer({
  canvas,
  alpha: true,
  antialias: false,
  powerPreference: 'high-performance'
});

renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setClearColor(0x000000, 0);

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(
  50,
  window.innerWidth / window.innerHeight,
  0.1,
  100
);
camera.position.z = 10;

// Cyan magic motes
const moteCount = window.innerWidth < 760 ? 65 : 160;
const positions = new Float32Array(moteCount * 3);
const speeds = new Float32Array(moteCount);

for (let i = 0; i < moteCount; i++) {
  positions[i * 3] = (Math.random() - 0.5) * 18;
  positions[i * 3 + 1] = (Math.random() - 0.5) * 10;
  positions[i * 3 + 2] = (Math.random() - 0.5) * 6;
  speeds[i] = 0.15 + Math.random() * 0.45;
}

const moteGeometry = new THREE.BufferGeometry();
moteGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));

const moteMaterial = new THREE.PointsMaterial({
  color: 0x2fe8ff,
  size: window.innerWidth < 760 ? 0.035 : 0.045,
  transparent: true,
  opacity: 0.52,
  depthWrite: false,
  blending: THREE.AdditiveBlending
});

const motes = new THREE.Points(moteGeometry, moteMaterial);
scene.add(motes);

// Warm embers near lower arena
const emberCount = window.innerWidth < 760 ? 30 : 90;
const emberPositions = new Float32Array(emberCount * 3);
const emberSpeeds = new Float32Array(emberCount);

for (let i = 0; i < emberCount; i++) {
  emberPositions[i * 3] = (Math.random() - 0.5) * 18;
  emberPositions[i * 3 + 1] = -5 + Math.random() * 3.2;
  emberPositions[i * 3 + 2] = (Math.random() - 0.5) * 5;
  emberSpeeds[i] = 0.1 + Math.random() * 0.3;
}

const emberGeometry = new THREE.BufferGeometry();
emberGeometry.setAttribute('position', new THREE.BufferAttribute(emberPositions, 3));

const emberMaterial = new THREE.PointsMaterial({
  color: 0xf4ad4c,
  size: 0.035,
  transparent: true,
  opacity: 0.55,
  depthWrite: false,
  blending: THREE.AdditiveBlending
});

const embers = new THREE.Points(emberGeometry, emberMaterial);
scene.add(embers);

const clock = new THREE.Clock();

function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), 0.04);

  const p = moteGeometry.attributes.position.array;
  for (let i = 0; i < moteCount; i++) {
    p[i * 3 + 1] += speeds[i] * dt;
    p[i * 3] += Math.sin(performance.now() * 0.0005 + i) * 0.0008;

    if (p[i * 3 + 1] > 5) {
      p[i * 3 + 1] = -5;
      p[i * 3] = (Math.random() - 0.5) * 18;
    }
  }
  moteGeometry.attributes.position.needsUpdate = true;

  const e = emberGeometry.attributes.position.array;
  for (let i = 0; i < emberCount; i++) {
    e[i * 3 + 1] += emberSpeeds[i] * dt;
    if (e[i * 3 + 1] > -1.7) {
      e[i * 3 + 1] = -5;
      e[i * 3] = (Math.random() - 0.5) * 18;
    }
  }
  emberGeometry.attributes.position.needsUpdate = true;

  renderer.render(scene, camera);
}

animate();

window.addEventListener('resize', () => {
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
  renderer.setSize(window.innerWidth, window.innerHeight);
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
});

// ----- Menu / prototype navigation -----

const modal = document.getElementById('modal');
const modalTitle = document.getElementById('modal-title');
const modalText = document.getElementById('modal-text');
const modalContent = document.getElementById('modal-content');
const modalKicker = document.getElementById('modal-kicker');

const views = {
  arena: {
    kicker: 'DIE ARENA',
    title: 'Arena betreten',
    text: 'Im nächsten Entwicklungsschritt startet hier das Matchmaking. Zwei Spieler setzen Relikte ein, verstecken sie auf zwei von sieben Positionen und treten in der Aufspürphase gegeneinander an.',
    stats: [
      ['7', 'POSITIONEN'],
      ['2', 'VERSTECKTE RELIKTE'],
      ['1×', 'AUFSPÜR-VERSUCH']
    ]
  },
  collection: {
    kicker: 'RELIKTKODEX',
    title: 'Deine Sammlung',
    text: 'Das langfristige Ziel sind 1.000 einzigartige Relikte. Sonderrunden und Events bringen exklusive Artefakte in den globalen Spieler-Pool.',
    stats: [
      ['0', 'ENTDECKT'],
      ['1000', 'GESAMT'],
      ['0%', 'FORTSCHRITT']
    ]
  },
  character: {
    kicker: 'JÄGERAUSWAHL',
    title: 'Wähle deinen Charakter',
    text: 'Hier entstehen die spielbaren Figuren. Zunächst wählen wir einen Charakter aus und stellen anschließend 10 von 50 verfügbaren Insignien und Gegenständen zusammen.',
    stats: [
      ['8', 'GEPLANTE JÄGER'],
      ['50', 'START-RELIKTE'],
      ['10', 'AUSWAHL']
    ]
  },
  settings: {
    kicker: 'SYSTEM',
    title: 'Einstellungen',
    text: 'Grafik, Sound, Sprache, Account und Barrierefreiheit werden hier später konfiguriert.',
    stats: [
      ['AUTO', 'GRAFIK'],
      ['DE', 'SPRACHE'],
      ['WEB', 'PLATTFORM']
    ]
  }
};

function openView(name) {
  if (name === 'home') {
    modal.classList.add('hidden');
    return;
  }

  const view = views[name];
  if (!view) return;

  modalKicker.textContent = view.kicker;
  modalTitle.textContent = view.title;
  modalText.textContent = view.text;

  modalContent.innerHTML = `
    <div class="stat-grid">
      ${view.stats.map(([value, label]) => `
        <div class="stat">
          <strong>${value}</strong>
          <span>${label}</span>
        </div>
      `).join('')}
    </div>
  `;

  modal.classList.remove('hidden');
}

document.querySelectorAll('[data-view]').forEach(button => {
  button.addEventListener('click', () => openView(button.dataset.view));
});

document.getElementById('modal-close').addEventListener('click', () => {
  modal.classList.add('hidden');
});

modal.addEventListener('click', event => {
  if (event.target === modal) modal.classList.add('hidden');
});

// Simple pointer parallax on desktop.
if (matchMedia('(pointer:fine)').matches) {
  const bg = document.querySelector('.scene-bg');
  window.addEventListener('pointermove', event => {
    const x = (event.clientX / window.innerWidth - 0.5) * -0.55;
    const y = (event.clientY / window.innerHeight - 0.5) * -0.35;
    bg.style.backgroundPosition = `${50 + x}% ${50 + y}%`;
  });
}

// Remove loader only after the visual backdrop is available.
// Includes timeout fallback so a network/module issue never traps the user.
const loading = document.getElementById('loading');

function finishLoading() {
  loading.classList.add('done');
}

const preload = new Image();
preload.src = './assets/arena-home-bg.png';
preload.onload = () => setTimeout(finishLoading, 500);
preload.onerror = () => finishLoading();

setTimeout(finishLoading, 3500);
